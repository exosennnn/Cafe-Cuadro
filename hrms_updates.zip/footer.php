</main>
  </div><!-- /app-wrapper -->

  <footer class="text-center text-muted small py-3 border-top" style="background: var(--cream, #f7f2ea);">
    &copy; <?= date('Y') ?> <?= APP_NAME ?>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script src="<?= BASE_URL ?>assets/hrms/js/script.js"></script>
  <script src="<?= BASE_URL ?>assets/shared/responsive.js?v=<?= ASSET_VER ?>"></script>

  <script>
  document.addEventListener('DOMContentLoaded', function () {
    const sidebar = document.getElementById('appSidebar');
    const toggleBtn = document.getElementById('sidebarToggle');
    // Hover-to-expand only makes sense on desktop with a real pointer
    if (!window.matchMedia('(min-width: 992px) and (hover: hover)').matches) return;
    if (toggleBtn) {
      toggleBtn.addEventListener('mouseenter', function () {
        document.body.classList.remove('sidebar-collapsed');
      });
    }
    if (sidebar) {
      sidebar.addEventListener('mouseleave', function () {
        document.body.classList.add('sidebar-collapsed');
      });
    }
  });
  </script>
</body>
</html>
